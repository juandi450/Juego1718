package org.izv.android.juego1718.currentgame;

import org.izv.android.juego1718.generic.GameBackground;

public class Background extends GameBackground {

    public Background() {
        super(Assets.bg);
    }
}